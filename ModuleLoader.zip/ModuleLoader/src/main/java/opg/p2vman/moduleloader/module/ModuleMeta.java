package opg.p2vman.moduleloader.module;

public class ModuleMeta {
    public String main_class;
    public String name;
}
