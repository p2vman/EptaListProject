package m.dict;

public interface Lock {
}
