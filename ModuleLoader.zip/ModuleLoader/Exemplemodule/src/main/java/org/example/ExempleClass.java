package org.example;

public class ExempleClass {
    public static void test() {
        System.out.println("Local class get");
    }
}
